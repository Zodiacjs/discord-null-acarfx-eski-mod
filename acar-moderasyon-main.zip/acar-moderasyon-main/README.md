# acar-moderasyon
Ceza bilgi sistemi, sicil, isim geçmişi, tepkili kayıt, Webhook Hoşgeldin ve daha daha Alın millet kod saklıyor ben de paylaşıyorum geliştirirsiniz!


./acar/acar-ayar.json
./acar/acar-veri.json
ikisini kendinize göre düzeltin etkinliklerde Ready.js de botun girişini düzeltebilirsiniz.
Sorusu veya herhangi bir şeyde bana yazabilirsiniz acar#0001
